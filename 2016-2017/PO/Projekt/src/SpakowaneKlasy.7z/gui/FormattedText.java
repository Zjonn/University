package gui;

import java.awt.Color;

import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

/**
 * Klasa zajmuje się wypisywaniem pokolorowanego testu.
 * 
 * @author Zjonn
 *
 */
public class FormattedText {
	/**
	 * Dopisuje text do już instniejącego
	 * 
	 * @param tp
	 *            Panel pozwalający zapisać pokolorowany tekst.
	 * @param msg
	 *            Tekst do napisania
	 * @param c
	 *            Kolor tekstu
	 */
	public void print(JTextPane tp, String msg, Color c) {
		printTextBase(tp, msg, c, false, false);
	}

	/**
	 * Nadpisuje poprzedni tekst
	 * 
	 * @param tp
	 *            Panel pozwalający zapisać pokolorowany tekst.
	 * @param msg
	 *            Tekst do napisania
	 * @param c
	 *            Kolor tekstu
	 */
	public void printc(JTextPane tp, String msg, Color c) {
		printTextBase(tp, msg, c, false, true);
	}

	/**
	 * Dopisuje text do już instniejącego i stawia znak nowej lini.
	 * 
	 * @param tp
	 *            Panel pozwalający zapisać pokolorowany tekst
	 * @param msg
	 *            Tekst do napisania
	 * @param c
	 *            Kolor tekstu
	 */
	public void println(JTextPane tp, String msg, Color c) {
		printTextBase(tp, msg, c, true, false);
	}

	/**
	 * Nadpisuje poprzedni tekst i stawia znak nowej lini.
	 * 
	 * @param tp
	 *            Panel pozwalający zapisać pokolorowany tekst
	 * @param msg
	 *            Tekst do napisania
	 * @param c
	 *            Kolor tekstu
	 */
	public void printcln(JTextPane tp, String msg, Color c) {
		printTextBase(tp, msg, c, true, true);
	}

	/**
	 * Czyści panel
	 * 
	 * @param tp
	 *            Panel do wyczyszczenia
	 */
	public void clear(JTextPane tp) {
		printTextBase(tp, "", Color.black, false, true);
	}

	/**
	 * Czyści panel i stawia znak nowej lini.
	 * 
	 * @param tp
	 *            Panel do wyczyszczenia
	 */
	public void clearnl(JTextPane tp) {
		printTextBase(tp, "", Color.black, true, true);
	}

	/**
	 * Funkcja wykonująca operacje na panelu.
	 * 
	 * @param tp
	 *            Panel
	 * @param msg
	 *            Tekst
	 * @param c
	 *            Kolor tesktu
	 * @param newLine
	 *            Czy nowa inia
	 * @param clearPanel
	 *            Czy nadpisać poprzedni tekst
	 */
	private void printTextBase(JTextPane tp, String msg, Color c, boolean newLine, boolean clearPanel) {
		StyleContext sc = StyleContext.getDefaultStyleContext();
		AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);

		aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Verdana");
		aset = sc.addAttribute(aset, StyleConstants.Alignment, StyleConstants.ALIGN_JUSTIFIED);

		if (!clearPanel) {
			int len = tp.getDocument().getLength();
			tp.setCaretPosition(len);
		}
		tp.setCharacterAttributes(aset, false);
		if (clearPanel) {
			if (newLine)
				tp.setText(msg + "\n");
			else
				tp.setText(msg);
		} else {
			if (newLine)
				tp.replaceSelection(msg + "\n");
			else
				tp.replaceSelection(msg);
		}
	}
}
