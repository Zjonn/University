#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

#include <windows.h>
#include <stdlib.h>
#include "resource.h"
#include <Commctrl.h>


/* Deklaracja wyprzedzaj�ca: funkcja obs�ugi okna */
LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);

INT_PTR CALLBACK AboutDlgProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain(HINSTANCE hThisInstance, HINSTANCE hPrevInstance,
	LPSTR lpszArgument, int nFunsterStil)
{
	HWND hwnd;
	MSG messages;

	hwnd = CreateWindowEx(
		0,
		"PRZYKLAD",
		"PRZYKLAD",
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT,
		450, 300,
		HWND_DESKTOP,
		NULL,
		hThisInstance,
		NULL
	);

	HWND hDlg = CreateDialog(GetModuleHandle(NULL),
		MAKEINTRESOURCE(IDD_DIALOG1),
		hwnd,
		AboutDlgProc);

	ShowWindow(hDlg, SW_SHOW);

	

	while (GetMessage(&messages, NULL, 0, 0))
	{
		/* T�umacz kody rozszerzone */
		TranslateMessage(&messages);
		/* Obs�u� komunikat */
		DispatchMessage(&messages);
	}
}

INT_PTR CALLBACK AboutDlgProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch (Message)
	{
	case WM_INITDIALOG:;
		TVITEM tvi;
		tvi.mask = TVIF_TEXT;
		tvi.pszText = "Element Jeden";
		
		TVINSERTSTRUCT tvins;
		tvins.item = tvi;
		tvins.hParent = tvins.hInsertAfter = TVI_ROOT;
		HTREEITEM hItem1 = TreeView_InsertItem(GetDlgItem(hwnd, IDC_TREE1), &tvins);
		tvi.pszText = "Element Dwa";
		tvins.item = tvi;
		tvins.hInsertAfter = TVI_LAST; // ...albo hItem1HTREEITEM
		HTREEITEM hItem2 = TreeView_InsertItem(GetDlgItem(hwnd, IDC_TREE1), &tvins);

		tvi.pszText = "Element Trzy";
		tvins.item = tvi;
		tvins.hInsertAfter = TVI_LAST; // ...albo hItem2HTREEITEM
		HTREEITEM hItem3 = TreeView_InsertItem(GetDlgItem(hwnd, IDC_TREE1), &tvins);

		tvi.pszText = "Dziecko Elementu Jeden";
		tvins.item = tvi;
		tvins.hParent = hItem1;
		tvins.hInsertAfter = TVI_FIRST; // ...albo TVI_LASTHTREEITEM
		HTREEITEM hItemChild = TreeView_InsertItem(GetDlgItem(hwnd, IDC_TREE1), &tvins);
		return TRUE;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDOK:;
			SendMessage(GetDlgItem(hwnd, IDC_PROGRESS1), PBM_DELTAPOS, (WPARAM)10, 0);
			break;
		case IDCANCEL:
			EndDialog(hwnd, IDCANCEL);
			PostQuitMessage(0);
			break;
		case ID_OPODMENU_MENUZBOKU:
			SetWindowLong(GetDlgItem(hwnd, IDC_PROGRESS1), GWL_STYLE, GetWindowLong(GetDlgItem(hwnd, IDC_PROGRESS1), GWL_STYLE) | PBS_MARQUEE);
			SendMessage(GetDlgItem(hwnd, IDC_PROGRESS1), PBM_SETMARQUEE, TRUE, 50);
			break;
		}
		break;
	default:
		return FALSE;
	}
	return TRUE;
}